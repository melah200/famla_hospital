<?php
  echo 'Date : '.date("d.m.Y").'<br>';
  echo 'Time : '.date("H:i:s").'<br>';
?>